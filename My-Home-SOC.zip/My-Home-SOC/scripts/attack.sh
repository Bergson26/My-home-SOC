# Simulation de 10 tentatives de connexion ratées en 5 secondes
for i in {1..10}; do
  ssh login-inexistant@localhost -p 22
done